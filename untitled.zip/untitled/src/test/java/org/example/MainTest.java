package org.example;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.ArrayList;
import java.util.Map;
import java.util.Vector;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MainTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }


    @ParameterizedTest
    @CsvSource({"1,1", "2,2", "3,3"})
    @Test
    void fibonacciTest(ArrayList<Integer> expected, ArrayList<Integer> actualInput) throws Exception {
        Vector<Executable> executables = new Vector<>();
        int len = expected.size();
        if(!expected.equals(actualInput.size()))
            throw new Exception();

        for(int i = 0; i<len; i++){
            executables.add(() -> assertEquals(expected[i], Main.fibonacci(actualInput.get(i)));
        }

        Assertions.assertAll(executables);
    }

}